#include <iostream>

using namespace std;

int main(int argc, char** argv){

	int x, y;
	
	cin >> x >> y;
	
	int sum = x+y;
	
	cout << sum << endl;

	return 0;
}
